/*************************************************
 	timers.h: Header file for operating timer T0 in Mode 1  
**************************************************/
// Functions contained in this header file
void timer0_init(void);

/*==========================================
	timer0_init(): This function initializes
								 timer T0 in Mode 1 and also 
								 enables its Interrupt. The 
								 timer overflows every 25ms.
============================================*/
void timer0_init(void){
	TMOD = 0x01; // setting T0 in Mode 1
	TH0 = 0x3C; 
	TL0 = 0xB0; // TH0 TL0 = 0x3CB0 == -50,000 => 50000x0.5us = 25ms
	EA = 1; // set the MSB for any other Interrupt to work
	ET0 = 1; // enabling the Interrupt for timer T0
	TR0 = 1; // starting the timer T0
}
