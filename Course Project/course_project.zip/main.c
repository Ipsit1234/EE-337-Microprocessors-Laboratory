/********************************************************************************************
	Name: Mantri Krishna Sri Ipsit
	Roll No: 180070032
	EE 337 Course Project Spring 2021
	Project Name: "Autofare"
********************************************************************************************/

// This is the main project file. All the main logic resides here

/************************************* Header files *****************************************/
#include <at89c5131.h>
#include "lcd.h"
#include "timers.h"
/***************** Declaring variables to be used in the logic ******************************/

sbit start = P1^0;// When 0 it denotes "Stop" state and when 1 it denotes "Start" state of the Auto
sbit wait = P1^3;// When 1 it denotes that Auto is in waiting state. Otherwise Auto is in motion        
sbit status1 = P1^1;// The MSB used for determining the speed of the Auto
sbit status2 = P1^2;// The LSB used for determining the speed of the Auto
 
unsigned int flag = 0;/* A variable used to ensure that the LCD is updated every 1 second.
											This is used because we know that it is not possible to get a 1 second 
											delay Using interrupts alone */											
unsigned int currentFare = 0;/* A variable used to store the current fare (Int) of the Auto*/
unsigned char statusStr[7] = {'\0'};/* A Char array used to store  the speed in Char datatype
                                    so that it can be written to the LCD */
unsigned char waiting[] = "Waiting";/* A variable which prints "Waiting" on LCD when wait == 1 */
unsigned int status = 360;/*A variable which stores the current speed based on the values of 
													the bits status1 and status2. The default value is given the lowest
													possible speed */
unsigned char currentFareStr[7] = {'\0'};/* A Char array which stores the current value of the
																					fare in Char datatype so that it can be written to
																					LCD */
unsigned char clear[16] = "                ";/* A string used to clear the bottom row of the 
																							LCD display.*/
unsigned char units[] = "km/h";/* A variable storing the units of Auto's speed */
unsigned char mumbaiAuto[] = "Mumbai Auto";/* A variable used to print "Mumbai Auto" on the 
																						first line of LCD before the start of the trip */
unsigned char forHire[] = "For Hire";/* A variable used to print "For Hire" on the 
																		second line of LCD before the start of the trip */
int i;/* A variable used in re-initializing the above variables when the Auto trip ends */
unsigned int waitingTime = 0;/* A variable used to store the waiting time of the Auto in 
														seconds */
float D = 0;/* A variable used to store the current Distance covered by the Auto */
float fare = 0;/* A variable used to store the current value of fare in `float` datatype */
/********************************** Function Definitions ************************************/

/*==========================================
	max(a, b): Finds and returns the maximum
					   among a and b
============================================*/
float max(float a, float b){
	if (a > b){
		return a;
	}
	else {
		return b;
	}
}

/*==========================================
	round(z): Rounds a floating point number z
						to its nearest integer. If its 
						decimal part is <= 0.49 then [z] 
						is returned otherwise [z] + 1 is
						returned where [.] denotes the 
						greatest integer function.
============================================*/
unsigned int round(float z){
	float a = z * 100; // Multiplying with 100 to get the first 2 decimal digits
	unsigned int s = a; // Converting Float to Int
	unsigned int res; // variable storing result
	if (s % 100 <= 49){ // if the last two digits are <= 49 then res = [z]
		res = s;
	}
	else { // else res = [z] + 1
		res = s + 1;
	}
	return res/100;// converting it back as we have initially multiplied with 100
}

/*==========================================
	floor(z): Returns [z] for a floating point
						number z where [.] denotes the 
						greatest integer function
============================================*/
unsigned int floor(float z){
	unsigned int a = z; // converts Float to Int
	return a;
}

/*==========================================
	stateInit(): A helper function used to
							 reset the values of fare,
							 speed, waiting time, D and
							 their corresponding Char
							 arrays if they exist.
============================================*/
void stateInit(void){
	currentFare = 0; // resetting the current fare to 0
	status = 360; // resetting the speed to 360 (default value)
	flag = 0; // resetting the flag to 0
	waitingTime = 0;// resetting the waiting time to 0
	D = 0;// resetting the distance covered D to 0
	fare = 0;// resetting the fare (Float) to 0
	for (i = 0; i < 7; i++){ // resetting the Char arrays to their default values
		statusStr[i] = '\0'; 
		currentFareStr[i] = '\0';
	}
}

/*==========================================
	checkStatus(): This is the Interrupt sub-
								 routine for timer T0. This
								 checks the status of the Auto
								 everytime the timer overflows.
								 When the timer finished 1s, it
								 prints the fare and status on
								 LCD.
============================================*/
void checkStatus(void) interrupt 1{
	TR0 = 0; // stopping the timer T0
	if (flag == 39){ /* the timer T0 overflows every 25ms. Hence when this happens 40 times it
											finishes 1s. Only then we will write to the LCD */
		if (start == 1){ // If the Auto is in start mode
			lcd_cmd(0x01); // clear the LCD screen
			msdelay(1);
			if (wait == 0){ // if the Auto is not in Waiting mode
				
				// Determining the speed of the Auto based on the values of port pins P1.1 and P1.2
				if (status1 == 0 && status2 == 0){
					status = 360;
				}
				else if (status1 == 0 && status2 == 1){
					status = 1800;
				}
				else if (status1 == 1 && status2 == 0){
					status = 720;
				}
				else if (status1 == 1 && status2 == 1){
					status = 3600;
				}
				else {}
				lcd_cmd(0xC0); // Put the cursor at the beginning of the bottom row of LCD
				msdelay(1);
				lcd_write_string(clear); // Send the string to clear the bottton row of LCD
				msdelay(1);
				lcd_cmd(0xC5); // Place the cursor at 6th position of the bottom row
				msdelay(1);
				int_to_string(status, statusStr); // convert the speed(status) of the Auto to a string
				lcd_write_string(statusStr); // Write the string to the LCD
				msdelay(1);
				lcd_cmd(0xCB); // Put the cursor at 12th position of the bottom row
				msdelay(1);
				lcd_write_string(units); // Write the units on the LCD
			}
			else { // If the Auto is in Waiting mode
				waitingTime = waitingTime + 1; // increment the waiting time every second
				lcd_cmd(0xC0); // Put the cursor at the beginning of the bottom row of LCD
				msdelay(1);
				lcd_write_string(clear); // Send the string to clear the bottton row of LCD
				msdelay(1);
				lcd_cmd(0xC5); // Place the cursor at 6th position of the bottom row
				msdelay(1);
				lcd_write_string(waiting);// Write the string `Waiting` to the LCD
				msdelay(1);
				status = 0; // setting status to 0 so that the increment in distance will be 0
			}
			D = D + 0.1 * (status / 360); // incrementing the distance covered based on the speed
			fare = 21 + 14.2 * max(D - 1.5, 0) + 1.42 * floor(waitingTime/5); /* calculating the  
																														fare as per the formula given */
			currentFare = round(fare); /* Rounding off the fare to handle the paise to Rupee issue */
			lcd_cmd(0x85); // Place the cursor on 6th position of top row of LCD
			msdelay(1);
			int_to_string(currentFare, currentFareStr); // Convert the fare to a string from Int
			lcd_write_string(currentFareStr); // Write the string to LCD
			msdelay(1);
		}
		else { // If the Auto is in Stop mode, do nothing
		}
		flag = 0; // As 1s is completed, reset the flag to 0
	}
	else { // If 1s is not completed by the Timer T0
		flag = flag + 1; // increase the flag
	}
	timer0_init(); // re-initialize and start the timer
}


/*==========================================
	main(): This is the main function
============================================*/
int main(void){
	P1 = 0x0F; // configuring P1.0 - P1.3 as inputs
	lcd_init(); // initialize the LCD
	lcd_cmd(0x82); // Put the cursor on the 3rd position from the left on the top row of LCD
	msdelay(1);
	lcd_write_string(mumbaiAuto); // Write `Mumbai Auto` to the LCD
	msdelay(1);
	lcd_cmd(0xC4); // Put the cursor at the 5th position on the bottom row of LCD
	lcd_write_string(forHire); // Write `For Hire` to the LCD
	msdelay(1);
	stateInit(); // Initialize the variables
	timer0_init(); // Initialize the timer T0
	while(1){
		if (start == 1){} /* When the Auto is in Start mode, the Interrupt subroutine takes care 
											of all the logic */
		else { // If the Auto is in Stop mode
			TR0 = 0; // Stop the timer
			stateInit(); // Reset the variables
			timer0_init(); // start and initialize the timer T0
		}
	}
}